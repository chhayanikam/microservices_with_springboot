package com.ecommapp.major.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.ecommapp.major.model.*;

public interface UserRepository extends JpaRepository<User,Integer> {
	//A custom method to find the user byemail
	Optional<User> findUserByEmail(String email);
}
