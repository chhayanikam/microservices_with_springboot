package com.ecommapp.major.model;
import java.util.List;

import javax.persistence.*;
import org.hibernate.validator.constraints.NotEmpty;
import lombok.Data;

@Entity
@Data
@Table(name="roles")
public class Role{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
private Integer id;

@NotEmpty
@Column(nullable=false,unique=true)
private String name;

@ManyToMany(mappedBy="roles")
private List<User> users;

public String getName() {
	// TODO Auto-generated method stub
	return name;
}
}