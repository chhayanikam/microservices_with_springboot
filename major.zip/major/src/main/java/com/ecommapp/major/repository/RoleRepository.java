package com.ecommapp.major.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommapp.major.model.Role;

public interface RoleRepository  extends JpaRepository<Role,Integer> {

}
