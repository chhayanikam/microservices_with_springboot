package com.myapp.jmsactivemqstandalone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmsActivemqStandaloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmsActivemqStandaloneApplication.class, args);
	}

}
