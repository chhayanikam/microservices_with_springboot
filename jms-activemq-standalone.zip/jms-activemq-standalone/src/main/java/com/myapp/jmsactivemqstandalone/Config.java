package com.myapp.jmsactivemqstandalone;

import javax.jms.Queue;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.core.JmsTemplate;

@EnableJms
@Configuration
public class Config {
	public Config() {
	System.out.println("JmsConfig object created...");	
	}	
	    @Value("${spring.activemq.broker-url}")
	    private String brokerUrl;

	    @Bean
	    public Queue queue() {
	    	System.out.println("JmsConfig  ActiveMQQueue('standalone.queue') created...");
          return new ActiveMQQueue("standalone.queue");
	    }

	    @Bean
	    public ActiveMQConnectionFactory activeMQConnectionFactory() {
	    	System.out.println("JmsConfig  ActiveMQConnectionFactory created...");
	    	      ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory();
	        factory.setBrokerURL(brokerUrl);
	        return factory;
	    }

	    @Bean
	    public JmsTemplate jmsTemplate() {
	      	System.out.println("JmsConfig  JmsTemplate created...");
	  	       return new JmsTemplate(activeMQConnectionFactory());
	    }
	
	
	
}
