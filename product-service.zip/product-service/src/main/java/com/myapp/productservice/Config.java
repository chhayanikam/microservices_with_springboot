package com.myapp.productservice;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class Config {
	Logger logger=Logger.getLogger("com.myapp.productservice.Config");
	
public Config() {
	logger.info("###Config Created###");

}	

@Bean
public RestTemplate restTemplate(){
	logger.info("###RestTemplate Created###");
	return new RestTemplate();
	
}

}
