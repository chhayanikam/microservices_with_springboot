package com.myapp.jmsactivemqinmemory;

import java.util.Date;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer1 {
	
	public Consumer1() {
	System.out.println("Consumer1 created....");
	}
	

    @JmsListener(destination = "inmemory.queue")
    public void listener(String message) {
        System.out.println("#####Consumer1  Received Message: " + message+" at "+new Date());
    }
}
