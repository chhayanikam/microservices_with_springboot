package com.myapp.jmsactivemqinmemory;

import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;

import javax.jms.Queue;

@EnableJms
@Configuration
public class Config {

	public Config() {
	System.out.println("JmsConfig object created...");	
	}
	
    @Bean
    public Queue queue() {
    	System.out.println(" ActiveMQQueue('inmemory.queue')  created");
    		return new ActiveMQQueue("inmemory.queue");
    }
    
}
