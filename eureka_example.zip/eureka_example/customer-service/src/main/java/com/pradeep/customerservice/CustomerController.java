package com.pradeep.customerservice;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CustomerController {

	Logger logger=Logger.getLogger("com.pradeep.customerservice.CustomerController");
	
	@Autowired
	private RestTemplate restTemplate;
	
		
	@Value("${server.port}")
	private String port;
	
	
	public CustomerController() {
	System.out.println("Customer Controller created...");
	logger.info("###CustomerController Created###");
	
	}
	
	@GetMapping("/names")
	public List<String> getAllCustomers(){
		logger.info("###CustomerController : calling getAllCustomers###");
			return Arrays.asList("RAM","RAHIM","DAVID",port);
	}
	
	@GetMapping("/products")
	public List getAllProducts(){
		logger.info("###CustomerController : calling getAllProducts###");
			return restTemplate.getForObject("http://localhost:5555/names", List.class);
										
	}
	
		
	
	
	
}
