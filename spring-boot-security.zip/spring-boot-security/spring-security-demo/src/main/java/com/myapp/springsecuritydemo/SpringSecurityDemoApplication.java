package com.myapp.springsecuritydemo;

import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@SpringBootApplication
public class SpringSecurityDemoApplication {

	@GetMapping("/hello")
	public String hello() {
		return "HEllo World!!";
	}
	
	@GetMapping("/welcome")
	public String welcome() {
		return "Welcome World!!";
	}
	
	
	@GetMapping("/today")
	public String today() {
		return "Today is"+new Date();
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityDemoApplication.class, args);
	}

}
